# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build System and Commands

This is a Qt6 desktop application that uses **CMake** as the build system. The project is configured for C++20 and uses Qt's Widgets framework.

### Building the Application

#### Development Build:
```bash
# Standard build
cmake -B build -S . -DCMAKE_BUILD_TYPE=Release
cmake --build build

# Debug build
cmake -B build -S . -DCMAKE_BUILD_TYPE=Debug
cmake --build build

# Build with Clang (for testing)
cmake -B build -S . -DCMAKE_BUILD_TYPE=Release -DUSE_CLANG=ON
cmake --build build
```

#### Debian Package Build:
```bash
# Build unsigned package for testing
dpkg-buildpackage -us -uc

# Build signed package for distribution  
dpkg-buildpackage

# Clean build artifacts
fakeroot debian/rules clean
```

#### CMake Targets:
- **`make`** or **`cmake --build build`**: Build the application
- **`make clean`**: Clean build artifacts
- **`make lupdate`**: Update translation files (runs clean-translations first)
- **`make translations`**: Generate .qm translation files
- **`make clean-translations`**: Remove .qm files before lupdate
- **`make install`**: Install the application

### Version Management
- Version is automatically generated from `debian/changelog` during debian package builds
- The build system extracts the version using sed and creates `src/version.h`
- Manual version updates should be made in `debian/changelog`

### Clean Build:
```bash
rm -rf build
rm -f translations/*.qm
```

## Architecture Overview

### Core Components
- **MainWindow** (`mainwindow.h/cpp`): Main application window with toolbar, splitter layout, and loading states
- **ConkyManager** (`conkymanager.h/cpp`): Central manager for conky discovery, execution, settings, and autostart functionality
- **ConkyItem** (`conkyitem.h/cpp`): Data model representing individual conky configurations with enabled/autostart states
- **ConkyListWidget** (`conkylistwidget.h/cpp`): List widget with checkboxes for multiple conky management
- **ConkyPreviewWidget**: Preview panel showing conky images and details
- **SettingsDialog** (`settingsdialog.h/cpp`): Dialog for managing search paths and application settings
- **ConkyCustomizeDialog** (`conkycustomizedialog.h/cpp`): Dialog for customizing conky appearance, position, and behavior
- **PreviewDialog** (`previewdialog.h/cpp`): Full-screen preview dialog for browsing and managing conkies
- **Cmd** (`cmd.h/cpp`): QProcess wrapper for executing shell commands safely
- **VersionNumber** (`versionnumber.h/cpp`): Version comparison utilities

### Application Structure
- Multi-conky management interface with checkbox-based selection and filtering
- Search and filter functionality for large conky collections
- Search path configuration for discovering conky files in multiple directories
- Autostart functionality with configurable delays between conky launches
- Preview system showing .png images from conky directories
- Edit integration with system default text editor (xdg-mime detection)
- Real-time status monitoring of running conky processes
- Loading states with animated indicators during scanning

### Key Features
- **Multiple Conky Management**: Run multiple conkies simultaneously with individual enable/disable controls
- **Autostart Configuration**: Set conkies to start automatically on login with customizable delays
- **Search Path Management**: Add/remove directories where conky files are located
- **Preview System**: Shows preview images (.png files) from conky directories
- **Edit Integration**: Opens conky files in default text editor with fallback to featherpad
- **Status Monitoring**: Real-time display of running/stopped status for each conky
- **Settings Persistence**: Saves enabled state, autostart settings, and search paths
- **Conky Customization**: Position, size, transparency, and other display options
- **Preview Dialog**: Full-screen browsing of conky collections
- **Copy Functionality**: Copy system conkies to user directories for customization
- **Filtering and Search**: Filter by status and search by name/description

### Data Model
- **ConkyItem Properties**:
  - File path and name
  - Description (extracted from conky files)
  - Enabled/disabled state
  - Autostart configuration with delay
  - Running status (monitored in real-time)
  - Preview image path (auto-detected .png files)
- **ConkyManager Functions**:
  - Directory scanning for conky files with extension detection
  - Process management (start/stop/restart) with PID tracking
  - Autostart sequencing with configurable delays
  - Settings persistence using QSettings
  - Status monitoring with QTimer-based updates

### Dependencies

#### Build Dependencies:
- Qt6 Core, GUI, Widgets, LinguistTools modules
- CMake 3.16+
- C++20 compatible compiler (GCC 9+ or Clang 10+)
- build-essential, debhelper-compat (for Debian packaging)

#### Runtime Dependencies:
- Qt6 runtime libraries
- conky (the system monitor application)
- System text editor (detected via xdg-mime, fallback to featherpad)
- Standard Linux utilities (pgrep, sed, etc.)

### File Organization
- **Source files**: `src/*.cpp`, `src/*.h` - All source code in src/ directory
- **Build files**: `CMakeLists.txt` - CMake configuration with Qt6 integration
- **Resources**: `images.qrc` with icons in `icons/` directory
- **Translations**: `translations/` directory with `.ts` source files and generated `.qm` files
- **Desktop translations**: `translations-desktop-file/` with extensive locale support (100+ languages)
- **Help documentation**: `help/` directory with HTML help files and images
- **Debian packaging**: `debian/` directory with full packaging configuration
- **Generated files**: `version.h` (generated from changelog), Qt MOC files in build directories

### UI Layout
- **Toolbar**: Settings, Refresh, Start Selected, Stop All, Autostart, Preview buttons
- **Filter/Search Bar**: Filter dropdown and search field for conky discovery
- **Main Area**: Splitter with conky list (left) and preview panel (right)
- **Conky List**: Tree widget with custom item widgets containing:
  - Enable checkbox with running status indicator
  - Autostart checkbox with delay spinner
  - Edit, Customize, and Start/Stop buttons
  - Conky name, description, and file path
- **Preview Panel**: Shows selected conky name, path, description, and preview image
- **Loading States**: Animated loading indicators during directory scanning

### Settings Storage
- Uses QSettings for persistent storage
- Settings group: "ConkyManager"
- Stores: search paths, enabled states, autostart configuration, window geometry
- Configuration location: `~/.config/MX-Linux/mx-conky.conf`

### Translation System
- **Application translations**: `.ts` files in `translations/` directory
- **Desktop file translations**: Separate system in `translations-desktop-file/`
- **Workflow**: 
  1. `make lupdate` - Extract translatable strings from source
  2. Edit `.ts` files with Qt Linguist
  3. `make translations` - Generate `.qm` runtime files
- **100+ supported locales** for desktop file integration

### Development Workflows

#### Adding New Features:
1. Update relevant header files in `src/`
2. Implement in corresponding `.cpp` files
3. Update CMakeLists.txt if adding new files
4. Test build with both GCC and Clang (USE_CLANG=ON)
5. Update translations if adding user-visible strings

#### Debugging:
- Use debug build: `cmake -B build -S . -DCMAKE_BUILD_TYPE=Debug`
- Qt Creator integration supported via CMakeLists.txt.user
- Console output available via qDebug() statements

#### Code Standards:
- C++20 standard with strict compiler warnings enabled
- Qt6 coding conventions
- Error handling for critical operations (file I/O, process management)
- Memory management via Qt's parent-child system and smart pointers

### Platform Support
- **Primary**: Linux (X11 and Wayland)
- **WSL Support**: Automatic QT_QPA_PLATFORM=xcb detection
- **Architecture**: x86_64 and i386 (with reduced compiler strictness for 32-bit)
- **Packaging**: Native Debian package support for Debian/Ubuntu derivatives