# AGENTS.md - mx-conky Development Guide

## Build & Test Commands
```bash
# Build (Release)
cmake -B build -S . -DCMAKE_BUILD_TYPE=Release && cmake --build build

# Build (Debug)  
cmake -B build -S . -DCMAKE_BUILD_TYPE=Debug && cmake --build build

# Clean build
rm -rf build && rm -f translations/*.qm

# Debian package
dpkg-buildpackage -us -uc

# Translation updates
make lupdate && make translations
```

## Code Style & Standards
- **Language**: C++20 with Qt6 Widgets framework
- **Headers**: Use `#pragma once`, group Qt includes before local includes
- **Naming**: PascalCase for classes, camelCase for methods/variables, m_ prefix for members
- **Formatting**: 4-space indentation, no trailing whitespace, {} on new lines for classes/functions
- **Error Handling**: Use Qt's error handling patterns, qDebug() for debugging output
- **Types**: Prefer Qt types (QString, QList) over STL, use auto where type is obvious
- **Memory**: Leverage Qt's parent-child system, use smart pointers for non-Qt objects
- **Compiler**: Strict warnings enabled (-Werror), must compile with both GCC and Clang