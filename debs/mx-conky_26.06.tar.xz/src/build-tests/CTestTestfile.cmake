# CMake generated Testfile for 
# Source directory: /home/adrian/Sync/programs/qt/mx-conky
# Build directory: /home/adrian/Sync/programs/qt/mx-conky/build-tests
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(mx-conky-tests "/home/adrian/Sync/programs/qt/mx-conky/build-tests/mx-conky-tests")
set_tests_properties(mx-conky-tests PROPERTIES  _BACKTRACE_TRIPLES "/home/adrian/Sync/programs/qt/mx-conky/CMakeLists.txt;209;add_test;/home/adrian/Sync/programs/qt/mx-conky/CMakeLists.txt;0;")
