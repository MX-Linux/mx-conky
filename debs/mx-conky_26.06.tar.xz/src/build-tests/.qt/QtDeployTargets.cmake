set(__QT_DEPLOY_TARGET_mx-conky_FILE /home/adrian/Sync/programs/qt/mx-conky/build-tests/mx-conky)
set(__QT_DEPLOY_TARGET_mx-conky_TYPE EXECUTABLE)
set(__QT_DEPLOY_TARGET_mx-conky-tests_FILE /home/adrian/Sync/programs/qt/mx-conky/build-tests/mx-conky-tests)
set(__QT_DEPLOY_TARGET_mx-conky-tests_TYPE EXECUTABLE)
