<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es">
<context>
    <name>ConkyCustomizeDialog</name>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="56"/>
        <source>Customize Conky - %1</source>
        <translation>Personalizar Conky - %1</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="77"/>
        <source>Launch</source>
        <translation>Lanzar</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="81"/>
        <location filename="../src/conkycustomizedialog.cpp" line="342"/>
        <source>Start</source>
        <translation>Iniciar</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="83"/>
        <source>Undo</source>
        <translation>Deshacer</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="106"/>
        <location filename="../src/conkycustomizedialog.cpp" line="186"/>
        <source>Colors</source>
        <translation>Colores</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="121"/>
        <source>Default</source>
        <translation>Predeterminado</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="121"/>
        <source>Color0</source>
        <translation>Color0 </translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="121"/>
        <source>Color1</source>
        <translation>Color1 </translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="121"/>
        <source>Color2</source>
        <translation>Color2 </translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="121"/>
        <source>Color3</source>
        <translation>Color3 </translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="121"/>
        <source>Color4</source>
        <translation>Color4 </translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="122"/>
        <source>Color5</source>
        <translation>Color5</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="122"/>
        <source>Color6</source>
        <translation>Color6</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="122"/>
        <source>Color7</source>
        <translation>Color7</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="122"/>
        <source>Color8</source>
        <translation>Color8</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="122"/>
        <source>Color9</source>
        <translation>Color9</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="193"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="337"/>
        <location filename="../src/conkycustomizedialog.cpp" line="342"/>
        <source>Stop</source>
        <translation>Detener</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="722"/>
        <source>Select Color</source>
        <translation>Seleccionar color</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="828"/>
        <source>Permission Denied</source>
        <translation>Permiso denegado</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="829"/>
        <source>Cannot write to file: %1
Insufficient permissions.</source>
        <translation>No se puede escribir el archivo: %1
Permisos insuficientes.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="839"/>
        <source>Write Error</source>
        <translation>Error de escritura</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="839"/>
        <source>Cannot write to file: %1</source>
        <translation>No se puede escribir el archivo: %1</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="930"/>
        <source>Backup Config File</source>
        <translation>Archivo de configuración de respaldo</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="930"/>
        <source>Do you want to preserve the original file?</source>
        <translation>¿Preservar el archivo original?</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="954"/>
        <source>Backed Up Config File</source>
        <translation>Archivo de configuración respaldado</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="955"/>
        <source>The original configuration was backed up to %1</source>
        <translation>La configuración original se guardó en %1</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="957"/>
        <source>Backup Failed</source>
        <translation>Falló la copia de respaldo</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="957"/>
        <source>Failed to create a backup file.</source>
        <translation>Error al crear la copia de respaldo.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1038"/>
        <location filename="../src/conkycustomizedialog.cpp" line="1041"/>
        <source>Restore Failed</source>
        <translation>Falló la restauración</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1038"/>
        <source>Failed to restore from backup file.</source>
        <translation>Error al restaurar desde la copia de respaldo.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1041"/>
        <source>Backup file does not exist.</source>
        <translation>No existe el archivo de respaldo.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1393"/>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1400"/>
        <source>Alignment</source>
        <translation>Alineación</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1405"/>
        <source>Top Left</source>
        <translation>Arriba a la izquierda</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1406"/>
        <source>Top Right</source>
        <translation>Arriba a la derecha</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1407"/>
        <source>Top Middle</source>
        <translation>Arriba en el centro</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1408"/>
        <source>Bottom Left</source>
        <translation>Abajo a la izquierda</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1409"/>
        <source>Bottom Right</source>
        <translation>Abajo a la derecha</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1410"/>
        <source>Bottom Middle</source>
        <translation>Abajo en el centro</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1411"/>
        <source>Middle Left</source>
        <translation>Centrado a la izquierda</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1412"/>
        <source>Middle Right</source>
        <translation>Centrado a la derecha</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1413"/>
        <source>Middle Middle</source>
        <translation>En el centro</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1418"/>
        <source>Horizontal Gap</source>
        <translation>Separación horizontal</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1419"/>
        <source>[GAP_X] Horizontal distance from window border (in pixels)</source>
        <translation>[GAP_X] Distancia horizontal desde el borde de la ventana (en pixels)</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1431"/>
        <source>Vertical Gap</source>
        <translation>Separación vertical</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1432"/>
        <source>[GAP_Y] Vertical distance from window border (in pixels)</source>
        <translation>[GAP_Y] Distancia vertical desde el borde de la ventana (en pixels)</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1444"/>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1447"/>
        <source>Desktop 1</source>
        <translation>Escritorio 1</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1448"/>
        <source>All Desktops</source>
        <translation>Todos los Escritorios</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1460"/>
        <source>Location</source>
        <translation>Ubicación</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1472"/>
        <source>Width should be larger than the size of window contents,
otherwise this setting will not have any effect</source>
        <translation>El ancho debe ser mayor que el tamaño del contenido de la ventana,
de lo contrario esta configuración no tendrá ningún efecto.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1476"/>
        <source>Minimum Width</source>
        <translation>Ancho mínimo</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1491"/>
        <source>Height should be larger than the size of window contents,
otherwise this setting will not have any effect</source>
        <translation>La altura debe ser mayor que el tamaño del contenido de la ventana,
de lo contrario esta configuración no tendrá ningún efecto.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1493"/>
        <source>Minimum Height</source>
        <translation>Altura mínima</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1507"/>
        <source>Increases the window height by adding empty lines at the end of the Conky config file</source>
        <translation>Aumenta la altura de la ventana agregando líneas vacías al final del archivo de configuración de Conky</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1508"/>
        <source>Height Padding</source>
        <translation>Espaciado de la altura</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1523"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1536"/>
        <source>Transparency Type</source>
        <translation>Tipo de transparencia</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1541"/>
        <source>Opaque</source>
        <translation>Opaco</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1542"/>
        <source>Transparent</source>
        <translation>Tansparente</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1543"/>
        <source>Pseudo-Transparent</source>
        <translation>Seudotransparente</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1544"/>
        <source>Semi-Transparent</source>
        <translation>Semitransparente</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1549"/>
        <source>Opacity (%)</source>
        <translation>Opacidad (%)</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1550"/>
        <source>Window Opacity

0 = Fully Transparent, 100 = Fully Opaque</source>
        <translation>Opacidad de la ventana

0 = Totalmente transparente, 100 = Totalmente opaco</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1564"/>
        <source>Background Color</source>
        <translation>Color de fondo</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1569"/>
        <source>Choose Color</source>
        <translation>Elegir color</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1589"/>
        <source>Setting Type to &quot;Transparent&quot; will make the whole window transparent (including any images). Use &quot;Pseudo-Transparent&quot; if you want the images to be opaque.</source>
        <translation>Al configurar el tipo como &quot;Transparente&quot;, toda la ventana será transparente (incluidas las imágenes). Si desea que las imágenes sean opacas, utilice &quot;Seudotransparente&quot;.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1599"/>
        <source>Setting Type to &quot;Pseudo-Transparent&quot; will make the window transparent but the window will have a shadow. The shadow can be disabled by configuring your window manager.</source>
        <translation>Al configurar el tipo como &quot;Seudotransparente&quot;, la ventana será transparente, pero tendrá una sombra. Esta sombra se puede desactivar configurando el gestor de ventanas.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1610"/>
        <source>Transparency</source>
        <translation>Transparencia</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1621"/>
        <source>Date Format</source>
        <translation>Formato de fecha</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1624"/>
        <source>Day</source>
        <translation>Día</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1626"/>
        <location filename="../src/conkycustomizedialog.cpp" line="1637"/>
        <source>Long</source>
        <translation>Largo</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1627"/>
        <location filename="../src/conkycustomizedialog.cpp" line="1638"/>
        <source>Short</source>
        <translation>Corto</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1628"/>
        <source>Abbreviated name, e.g. Tu</source>
        <translation>Nombre abreviado, por ejemplo, Mar</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1635"/>
        <source>Month</source>
        <translation>Mes</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1639"/>
        <source>Abbreviated name, e.g. Oct</source>
        <translation>Nombre abreviado, p. ej. Oct</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1658"/>
        <source>Time Format</source>
        <translation>Formato de hora</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1665"/>
        <source>Format</source>
        <translation>Formatear</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1670"/>
        <source>12 Hour</source>
        <translation>12 horas</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1671"/>
        <source>24 Hour</source>
        <translation>24 horas</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="653"/>
        <location filename="../src/conkycustomizedialog.cpp" line="662"/>
        <location filename="../src/conkycustomizedialog.cpp" line="671"/>
        <source>auto</source>
        <translation>automático</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1686"/>
        <source>Date &amp;&amp; Time</source>
        <translation>Fecha &amp;&amp; Hora</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1699"/>
        <source>Interface</source>
        <translation>Interfaz</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1707"/>
        <source>WiFi</source>
        <translation>WiFi</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1710"/>
        <source>WiFi Network</source>
        <translation>Red WiFi</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1713"/>
        <source>LAN</source>
        <translation>LAN</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1716"/>
        <source>Wired LAN Network</source>
        <translation>Red LAN cableada</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1730"/>
        <source>Network</source>
        <translation>Red</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="2045"/>
        <source>Select Background Color</source>
        <translation>Seleccionar color de fondo</translation>
    </message>
</context>
<context>
    <name>ConkyItemWidget</name>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="64"/>
        <source>Running</source>
        <translation>Ejecutándose</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="64"/>
        <source>Stopped</source>
        <translation>Detenido</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="138"/>
        <source>Autostart</source>
        <translation>Autoinicio</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="140"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="143"/>
        <source>Customize</source>
        <translation>Personalizar</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="148"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="177"/>
        <source>Stop</source>
        <translation>Detener</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="180"/>
        <source>Start</source>
        <translation>Iniciar</translation>
    </message>
</context>
<context>
    <name>ConkyListWidget</name>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="345"/>
        <source>Total: 0 conkies</source>
        <translation>Total: 0 conkies</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="595"/>
        <source>Total: %1 conkies</source>
        <translation>Total: %1 conkies</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="598"/>
        <source>Showing: %1 of %2 conkies</source>
        <translation>Mostrando: %1 de %2 conkies</translation>
    </message>
</context>
<context>
    <name>ConkyPreviewWidget</name>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="548"/>
        <source>No Conky Selected</source>
        <translation>No se ha seleccionado ningún Conky</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="550"/>
        <source>Select a conky from the list to see its preview</source>
        <translation>Seleccione un conky de la lista para ver su vista previa</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="569"/>
        <source>Preview image could not be loaded</source>
        <translation>No se pudo cargar la imagen de vista previa</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="572"/>
        <source>No preview image available</source>
        <translation>No hay ninguna imagen de vista previa disponible</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.cpp" line="58"/>
        <location filename="../src/mainwindow.cpp" line="934"/>
        <source>MX Conky</source>
        <translation>MX Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="322"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="320"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="327"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="342"/>
        <source>Quit application</source>
        <translation>Terminar aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="340"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="230"/>
        <source>Loading Conky configurations...</source>
        <translation>Cargando configuración de Conky...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="260"/>
        <source>Settings</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="262"/>
        <source>Configure conky search paths</source>
        <translation>Configurar rutas de búsqueda de conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="264"/>
        <source>Refresh</source>
        <translation>Refrescar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="266"/>
        <source>Refresh conky list</source>
        <translation>Refrescar lista de conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="268"/>
        <source>Start All</source>
        <translation>Iniciar todo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="270"/>
        <source>Start all enabled conkies</source>
        <translation>Iniciar todos los conkies habilitados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="272"/>
        <source>Stop All</source>
        <translation>Detener todo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="274"/>
        <source>Stop all running conkies</source>
        <translation>Detener todos los conkies en ejecución</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="948"/>
        <source>MX Conky License</source>
        <translation>Licencia de MX Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="999"/>
        <location filename="../src/mainwindow.cpp" line="1050"/>
        <source>Running</source>
        <translation>Ejecutándose</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1001"/>
        <location filename="../src/mainwindow.cpp" line="1051"/>
        <source>Stopped</source>
        <translation>Detenido</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="282"/>
        <source>Search conky by name...</source>
        <translation>Buscar conky por nombre...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="284"/>
        <source>Search conkies by name (Ctrl+F)</source>
        <translation>Buscar conkies por nombre (Ctrl+F)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="329"/>
        <source>Display help</source>
        <translation>Mostrar ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="518"/>
        <location filename="../src/mainwindow.cpp" line="692"/>
        <source>Copy Conky</source>
        <translation>Copiar Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="564"/>
        <location filename="../src/mainwindow.cpp" line="740"/>
        <source>Conky Copied</source>
        <translation>Conky copiado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="565"/>
        <source>Conky has been copied to your personal folder for editing:
%1</source>
        <translation>Conky se ha copiado a tu carpeta personal para editarlo:
%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="567"/>
        <location filename="../src/mainwindow.cpp" line="743"/>
        <source>Copy Failed</source>
        <translation>Copia fallida</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="567"/>
        <location filename="../src/mainwindow.cpp" line="743"/>
        <source>Failed to copy conky to your personal folder.</source>
        <translation>No se pudo copiar conky a su carpeta personal.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="629"/>
        <source>Delete Conky</source>
        <translation>Eliminar Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="741"/>
        <source>Conky has been copied to your personal folder for customization:
%1</source>
        <translation>Conky se ha copiado a tu carpeta personal para personalizarlo:
%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="256"/>
        <source>Previews</source>
        <translation>Vistas previas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="258"/>
        <source>Generate preview images for conkies</source>
        <translation>Generar imágenes de vista previa para conkies</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="278"/>
        <location filename="../src/mainwindow.cpp" line="552"/>
        <location filename="../src/mainwindow.cpp" line="728"/>
        <location filename="../src/mainwindow.cpp" line="997"/>
        <location filename="../src/mainwindow.cpp" line="1049"/>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="279"/>
        <source>Filter conkies by running status or location</source>
        <translation>Filtrar conkies por estado de ejecución o ubicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="514"/>
        <location filename="../src/mainwindow.cpp" line="688"/>
        <source>Enter a name for the copy:</source>
        <translation>Introduzca un nombre para la copia:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="515"/>
        <location filename="../src/mainwindow.cpp" line="689"/>
        <source>In order for you to edit and save a conky, it must first be copied to ~/.conky where you have permission.
Enter a name for the copy.</source>
        <translation>Para editar y guardar un conky, primero debe copiarlo a ~/.conky, donde tenga permiso.
Ingrese un nombre para la copia.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="532"/>
        <location filename="../src/mainwindow.cpp" line="708"/>
        <source>Directory Exists</source>
        <translation>El directorio existe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="533"/>
        <location filename="../src/mainwindow.cpp" line="709"/>
        <source>A conky with the name '%1' already exists in your personal folder.
Do you want to overwrite it?</source>
        <translation>Ya existe un archivo con el nombre &apos;%1&apos; en tu carpeta personal. ¿Quieres sobrescribirlo?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="600"/>
        <source>Edit Conky</source>
        <translation>Editar Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="601"/>
        <source>This conky file is read-only and requires administrator privileges to edit.
Do you want to edit it with elevated privileges?</source>
        <translation>Este archivo conky es de solo lectura y requiere privilegios de administrador para editarlo.
¿Quieres editarlo con privilegios elevados?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="630"/>
        <source>Are you sure you want to delete the conky file:
%1

This action cannot be undone.</source>
        <translation>¿Seguro que desea eliminar el archivo conky?
%1

Esta acción no se puede deshacer.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="662"/>
        <source>Delete Failed</source>
        <translation>Falló la eliminación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="662"/>
        <source>Failed to delete conky file:
%1</source>
        <translation>No se pudo eliminar el archivo conky:
%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="750"/>
        <source>Customize Conky</source>
        <translation>Personalizar Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="751"/>
        <source>This conky file is read-only and requires administrator privileges to customize.
Do you want to customize it with elevated privileges?</source>
        <translation>Este archivo conky es de solo lectura y requiere privilegios de administrador para personalizarlo.
¿Quieres personalizarlo con privilegios elevados?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="923"/>
        <source>Editor Error</source>
        <translation>Error del editor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="923"/>
        <source>Cannot start editor for file: %1</source>
        <translation>No se puede iniciar el editor del archivo: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="933"/>
        <source>About MX Conky</source>
        <translation>Acerca de MX Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="935"/>
        <source>Version: </source>
        <translation>Versión:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="936"/>
        <source>GUI program for configuring Conky in MX Linux</source>
        <translation>Programa gráfico para configurar Conky en MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="939"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Derechos de autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="940"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="941"/>
        <location filename="../src/mainwindow.cpp" line="951"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="942"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="136"/>
        <location filename="../src/mainwindow.cpp" line="962"/>
        <source>&amp;Close</source>
        <translation>&amp;Close</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="979"/>
        <source>MX Conky Help</source>
        <translation>Ayuda para MX Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1003"/>
        <location filename="../src/mainwindow.cpp" line="1052"/>
        <source>Autostart</source>
        <translation>Autoinicio</translation>
    </message>
</context>
<context>
    <name>PreviewDialog</name>
    <message>
        <location filename="../src/previewdialog.cpp" line="50"/>
        <source>Generate Preview</source>
        <translation>Generar vista previa</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="75"/>
        <source>Generate preview images for</source>
        <translation>Generar imágenes de vista previa para</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="78"/>
        <source>Selected Widget</source>
        <translation>Widget seleccionado</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="79"/>
        <source>All Widgets with Missing Previews</source>
        <translation>Todos los widgets con vistas previas faltantes</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="80"/>
        <source>All Widgets (Overwrite Existing Images)</source>
        <translation>Todos los widgets (sobrescribir imágenes existentes)</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="85"/>
        <source>No conky is currently selected</source>
        <translation>No hay ningún conky seleccionado actualmente</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="93"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="96"/>
        <source>High quality images (PNG)</source>
        <translation>Imágenes de alta calidad (PNG)</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="97"/>
        <source>Generate preview images in PNG format instead of JPEG</source>
        <translation>Generar imágenes de vista previa en formato PNG en lugar de JPEG</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="114"/>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="118"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="145"/>
        <source>No Items</source>
        <translation>No hay elementos</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="145"/>
        <source>No conky widgets need preview generation.</source>
        <translation>No es necesario generar una vista previa de los widgets Conky.</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="151"/>
        <source>Missing Dependency</source>
        <translation>Dependencia faltante</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="152"/>
        <source>Preview generation requires the GraphicsMagick compatibility tools.
Please install the graphicsmagick-imagemagick-compat package to enable this feature.</source>
        <translation>La generación de vistas previas requiere las herramientas de compatibilidad GraphicsMagick.
Instale el paquete graphicsmagick-imagemagick-compat para habilitar esta función.</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="163"/>
        <source>Starting preview generation...</source>
        <translation>Iniciando la generación de vista previa...</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="167"/>
        <source>Stop</source>
        <translation>Detener</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="206"/>
        <source>Generating preview for: %1</source>
        <translation>Generando vista previa para: %1</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="426"/>
        <source>Preview generation complete! Generated %1 previews.</source>
        <translation>¡Generación de vista previa completa! Se generaron %1 vistas previas.</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="430"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="433"/>
        <source>Preview Generation Complete</source>
        <translation>Generación de vista previa completa</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="434"/>
        <source>Successfully generated %1 preview images.</source>
        <translation>Se generaron exitosamente %1 imágenes de vista previa.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="68"/>
        <source>Select Conky Manager config file</source>
        <translation>Seleccionar archivo de configuración del Gestor de Conky</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program as normal user</source>
        <translation>Tiene que ejecutar este programa como usuario normal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="163"/>
        <source>Could not load %1</source>
        <translation>No se pudo cargar %1</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../src/settingsdialog.cpp" line="40"/>
        <location filename="../src/settingsdialog.cpp" line="62"/>
        <source>Select Conky Directory</source>
        <translation>Seleccionar el directorio Conky</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="83"/>
        <source>MX Conky Settings</source>
        <translation>Configuración de MX Conky</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="91"/>
        <source>Search Paths</source>
        <translation>Ruta de búsqueda</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="92"/>
        <source>Autostart</source>
        <translation>Autoinicio</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="167"/>
        <source>Conky Search Paths</source>
        <translation>Rutas de búsqueda de Conky</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="173"/>
        <source>Add Path</source>
        <translation>Agregar ruta</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="176"/>
        <source>Remove Path</source>
        <translation>Eliminar ruta</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="179"/>
        <source>Edit Path</source>
        <translation>Editar ruta</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="206"/>
        <source>Autostart Settings</source>
        <translation>Ajustes de Autoinicio</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="209"/>
        <source>Start conky at system startup</source>
        <translation>Iniciar conky al iniciar el sistema</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="212"/>
        <source>Startup delay (seconds):</source>
        <translation>Retraso de inicio (segundos):</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="95"/>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
</TS>