<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="de">
<context>
    <name>ConkyCustomizeDialog</name>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="56"/>
        <source>Customize Conky - %1</source>
        <translation>Individualisierung Conky - %1</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="77"/>
        <source>Launch</source>
        <translation>Starten</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="81"/>
        <location filename="../src/conkycustomizedialog.cpp" line="342"/>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="83"/>
        <source>Undo</source>
        <translation>Rückgängig</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="106"/>
        <location filename="../src/conkycustomizedialog.cpp" line="186"/>
        <source>Colors</source>
        <translation>Farben</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="121"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="121"/>
        <source>Color0</source>
        <translation>Farbe0</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="121"/>
        <source>Color1</source>
        <translation>Farbe1</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="121"/>
        <source>Color2</source>
        <translation>Farbe2</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="121"/>
        <source>Color3</source>
        <translation>Farbe3</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="121"/>
        <source>Color4</source>
        <translation>Farbe4</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="122"/>
        <source>Color5</source>
        <translation>Farbe5</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="122"/>
        <source>Color6</source>
        <translation>Farbe6</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="122"/>
        <source>Color7</source>
        <translation>Farbe7</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="122"/>
        <source>Color8</source>
        <translation>Farbe8</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="122"/>
        <source>Color9</source>
        <translation>Farbe9</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="193"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="337"/>
        <location filename="../src/conkycustomizedialog.cpp" line="342"/>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="722"/>
        <source>Select Color</source>
        <translation>Auswahl Farbe</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="828"/>
        <source>Permission Denied</source>
        <translation>Erlaubnis verweigert</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="829"/>
        <source>Cannot write to file: %1
Insufficient permissions.</source>
        <translation>Schreiben in Datei: %1 fehlgeschlagen
Berechtigungen nicht ausreichend.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="839"/>
        <source>Write Error</source>
        <translation>Fehler beim Schreibversuch</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="839"/>
        <source>Cannot write to file: %1</source>
        <translation>Schreiben in Datei: %1 fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="930"/>
        <source>Backup Config File</source>
        <translation>Konfigurationsdatei sichern</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="930"/>
        <source>Do you want to preserve the original file?</source>
        <translation>Soll die Originaldatei behalten werden ?</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="954"/>
        <source>Backed Up Config File</source>
        <translation>Konfigurationsdatei gesichert</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="955"/>
        <source>The original configuration was backed up to %1</source>
        <translation>Die Originalkonfiguration wurde in %1 gesichert</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="957"/>
        <source>Backup Failed</source>
        <translation>Sichern fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="957"/>
        <source>Failed to create a backup file.</source>
        <translation>Erstellung einer Sicherungsdatei fehlgeschlagen.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1038"/>
        <location filename="../src/conkycustomizedialog.cpp" line="1041"/>
        <source>Restore Failed</source>
        <translation>Wiederherstellung fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1038"/>
        <source>Failed to restore from backup file.</source>
        <translation>Wiederherstellung aus einer Sicherungsdatei fehlgeschlagen.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1041"/>
        <source>Backup file does not exist.</source>
        <translation>Sicherungsdatei existiert nicht.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1393"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1400"/>
        <source>Alignment</source>
        <translation>Ausrichtung</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1405"/>
        <source>Top Left</source>
        <translation>Oben links</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1406"/>
        <source>Top Right</source>
        <translation>Oben rechts</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1407"/>
        <source>Top Middle</source>
        <translation>Oben Mitte</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1408"/>
        <source>Bottom Left</source>
        <translation>Unten links</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1409"/>
        <source>Bottom Right</source>
        <translation>Unten rechts</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1410"/>
        <source>Bottom Middle</source>
        <translation>Unten Mitte</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1411"/>
        <source>Middle Left</source>
        <translation>Mitte links</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1412"/>
        <source>Middle Right</source>
        <translation>Mitte rechts</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1413"/>
        <source>Middle Middle</source>
        <translation>Mitte Mitte</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1418"/>
        <source>Horizontal Gap</source>
        <translation>Horizontale Lücke</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1419"/>
        <source>[GAP_X] Horizontal distance from window border (in pixels)</source>
        <translation>[LÜCKE_X] Horizontale Distanz von der Fenstergrenze (in Pixel)</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1431"/>
        <source>Vertical Gap</source>
        <translation>Vertikale Lücke</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1432"/>
        <source>[GAP_Y] Vertical distance from window border (in pixels)</source>
        <translation>[LÜCKE_Y] Vertikale Distanz von der Fenstergrenze (in Pixel)</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1444"/>
        <source>Desktop</source>
        <translation>Arbeitsoberfläche</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1447"/>
        <source>Desktop 1</source>
        <translation>Arbeitsoberfläche 1</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1448"/>
        <source>All Desktops</source>
        <translation>Alle Arbeitsoberflächen</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1460"/>
        <source>Location</source>
        <translation>Speicherort</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1472"/>
        <source>Width should be larger than the size of window contents,
otherwise this setting will not have any effect</source>
        <translation>Weite sollte größer sein als die Größe des Fensterinhalts,
andernfalls hat diese Einstellung keinerlei Effekt</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1476"/>
        <source>Minimum Width</source>
        <translation>Minimalweite</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1491"/>
        <source>Height should be larger than the size of window contents,
otherwise this setting will not have any effect</source>
        <translation>Höhe sollte größer sein als die Größe des Fensterinhalts,
andernfalls hat diese Einstellung keinerlei Effekt</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1493"/>
        <source>Minimum Height</source>
        <translation>Minimalhöhe</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1507"/>
        <source>Increases the window height by adding empty lines at the end of the Conky config file</source>
        <translation>Die Fensterhöhe wird vergrößert durch das Hinzufügen von Leerzeilen am Ende der Conky Konfigurationsdatei</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1508"/>
        <source>Height Padding</source>
        <translation>Höhe auffüllen</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1523"/>
        <source>Size</source>
        <translation>Größe</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1536"/>
        <source>Transparency Type</source>
        <translation>Transparenztyp</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1541"/>
        <source>Opaque</source>
        <translation>Opaque</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1542"/>
        <source>Transparent</source>
        <translation>Transparent</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1543"/>
        <source>Pseudo-Transparent</source>
        <translation>Pseudo-Transparent</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1544"/>
        <source>Semi-Transparent</source>
        <translation>Semi-Transparent</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1549"/>
        <source>Opacity (%)</source>
        <translation>Transparenz (%)</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1550"/>
        <source>Window Opacity

0 = Fully Transparent, 100 = Fully Opaque</source>
        <translation>Fenstertransparenz

0 = vollständig transparent, 100 = vollständig opaque</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1564"/>
        <source>Background Color</source>
        <translation>Hintergrundfarbe</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1569"/>
        <source>Choose Color</source>
        <translation>Auswahl Farbe</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1589"/>
        <source>Setting Type to &quot;Transparent&quot; will make the whole window transparent (including any images). Use &quot;Pseudo-Transparent&quot; if you want the images to be opaque.</source>
        <translation>Setzen des Typs auf &quot;transparent&quot; macht das ganze Fenster transparent (inklusive aller Bilder). Sollen die Bilder opaque sein bitte &quot;pseudo-transparent&quot; benutzen.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1599"/>
        <source>Setting Type to &quot;Pseudo-Transparent&quot; will make the window transparent but the window will have a shadow. The shadow can be disabled by configuring your window manager.</source>
        <translation>Setzen des Typs auf &quot;pseudo-transparent&quot; macht das Fenster transparent aber haben einen Schatten.. Der Schatten kann verhindert werden durch Konfigurierung des Fenstermanagers.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1610"/>
        <source>Transparency</source>
        <translation>Transparenz</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1621"/>
        <source>Date Format</source>
        <translation>Datumsformat</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1624"/>
        <source>Day</source>
        <translation>Tag</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1626"/>
        <location filename="../src/conkycustomizedialog.cpp" line="1637"/>
        <source>Long</source>
        <translation>Lange</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1627"/>
        <location filename="../src/conkycustomizedialog.cpp" line="1638"/>
        <source>Short</source>
        <translation>Kurz</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1628"/>
        <source>Abbreviated name, e.g. Tu</source>
        <translation>Abgekürzter Name, z.B. Di</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1635"/>
        <source>Month</source>
        <translation>Monat</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1639"/>
        <source>Abbreviated name, e.g. Oct</source>
        <translation>Abgekürzter Name, z.B. Okt</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1658"/>
        <source>Time Format</source>
        <translation>Zeitformat</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1665"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1670"/>
        <source>12 Hour</source>
        <translation>12 Stunden</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1671"/>
        <source>24 Hour</source>
        <translation>24 Stunden</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="653"/>
        <location filename="../src/conkycustomizedialog.cpp" line="662"/>
        <location filename="../src/conkycustomizedialog.cpp" line="671"/>
        <source>auto</source>
        <translation>Automatisch</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1686"/>
        <source>Date &amp;&amp; Time</source>
        <translation>Datum &amp;&amp; Zeit</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1699"/>
        <source>Interface</source>
        <translation>Schnittstelle</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1707"/>
        <source>WiFi</source>
        <translation>WiFi</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1710"/>
        <source>WiFi Network</source>
        <translation>WiFi Netzwerk</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1713"/>
        <source>LAN</source>
        <translation>LAN</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1716"/>
        <source>Wired LAN Network</source>
        <translation>drahtgebundenes LAN Network</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1730"/>
        <source>Network</source>
        <translation>Netzwerk</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="2045"/>
        <source>Select Background Color</source>
        <translation>Auswahl Hintergrundfarbe</translation>
    </message>
</context>
<context>
    <name>ConkyItemWidget</name>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="64"/>
        <source>Running</source>
        <translation>Ist am Laufen</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="64"/>
        <source>Stopped</source>
        <translation>Gestoppt</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="138"/>
        <source>Autostart</source>
        <translation>Autostart</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="140"/>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="143"/>
        <source>Customize</source>
        <translation>Individualisiere</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="148"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="177"/>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="180"/>
        <source>Start</source>
        <translation>Start</translation>
    </message>
</context>
<context>
    <name>ConkyListWidget</name>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="345"/>
        <source>Total: 0 conkies</source>
        <translation>Total: 0 Conkies</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="595"/>
        <source>Total: %1 conkies</source>
        <translation>Total: %1 Conkies</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="598"/>
        <source>Showing: %1 of %2 conkies</source>
        <translation>Anzeige: %1 von %2 Conkies</translation>
    </message>
</context>
<context>
    <name>ConkyPreviewWidget</name>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="548"/>
        <source>No Conky Selected</source>
        <translation>Kein Conky ausgewählt</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="550"/>
        <source>Select a conky from the list to see its preview</source>
        <translation>Für eine Vorschau ein Conky aus der Liste auswählen</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="569"/>
        <source>Preview image could not be loaded</source>
        <translation>Vorschau konnte nicht geladen werden.</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="572"/>
        <source>No preview image available</source>
        <translation>Keine Vorschau verfügbar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.cpp" line="58"/>
        <location filename="../src/mainwindow.cpp" line="934"/>
        <source>MX Conky</source>
        <translation>MX-Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="322"/>
        <source>About this application</source>
        <translation>Über diese Anwendung</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="320"/>
        <source>About...</source>
        <translation>Über...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="327"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="342"/>
        <source>Quit application</source>
        <translation>Anwendung beenden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="340"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="230"/>
        <source>Loading Conky configurations...</source>
        <translation>Conky Einstellungen werden geladen...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="260"/>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="262"/>
        <source>Configure conky search paths</source>
        <translation>Conky Suchpfade einstellen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="264"/>
        <source>Refresh</source>
        <translation>Aktualisieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="266"/>
        <source>Refresh conky list</source>
        <translation>Conky Liste aktualisieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="268"/>
        <source>Start All</source>
        <translation>Alles starten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="270"/>
        <source>Start all enabled conkies</source>
        <translation>Alle verfügbaren Conkies starten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="272"/>
        <source>Stop All</source>
        <translation>Alles stoppen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="274"/>
        <source>Stop all running conkies</source>
        <translation>Alle laufenden Conkies stoppen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="948"/>
        <source>MX Conky License</source>
        <translation>MX Conky Lizenz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="999"/>
        <location filename="../src/mainwindow.cpp" line="1050"/>
        <source>Running</source>
        <translation>Ist am Laufen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1001"/>
        <location filename="../src/mainwindow.cpp" line="1051"/>
        <source>Stopped</source>
        <translation>Gestoppt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="282"/>
        <source>Search conky by name...</source>
        <translation>Conky per Namen suchen...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="284"/>
        <source>Search conkies by name (Ctrl+F)</source>
        <translation>Conkies per Namen suchen (Ctrl+F)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="329"/>
        <source>Display help</source>
        <translation>Hilfe anzeigen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="518"/>
        <location filename="../src/mainwindow.cpp" line="692"/>
        <source>Copy Conky</source>
        <translation>Conky kopieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="564"/>
        <location filename="../src/mainwindow.cpp" line="740"/>
        <source>Conky Copied</source>
        <translation>Conky kopiert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="565"/>
        <source>Conky has been copied to your personal folder for editing:
%1</source>
        <translation>Conky wurde zum Bearbeiten in das persönliche Verzeichnis kopiert:
%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="567"/>
        <location filename="../src/mainwindow.cpp" line="743"/>
        <source>Copy Failed</source>
        <translation>Kopieren fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="567"/>
        <location filename="../src/mainwindow.cpp" line="743"/>
        <source>Failed to copy conky to your personal folder.</source>
        <translation>Kopieren von Conky in das persönliche Verzeichnis fehlgeschlagen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="629"/>
        <source>Delete Conky</source>
        <translation>Conky löschen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="741"/>
        <source>Conky has been copied to your personal folder for customization:
%1</source>
        <translation>Conky wurde zum Individualisieren in das persönliche Verzeichnis kopiert:
%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="256"/>
        <source>Previews</source>
        <translation>Vorschau</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="258"/>
        <source>Generate preview images for conkies</source>
        <translation>Erzeugung von Vorschauabbildern für Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="278"/>
        <location filename="../src/mainwindow.cpp" line="552"/>
        <location filename="../src/mainwindow.cpp" line="728"/>
        <location filename="../src/mainwindow.cpp" line="997"/>
        <location filename="../src/mainwindow.cpp" line="1049"/>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="279"/>
        <source>Filter conkies by running status or location</source>
        <translation>Filtern der Conkies nach Anwendungsstatus oder Lokation</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="514"/>
        <location filename="../src/mainwindow.cpp" line="688"/>
        <source>Enter a name for the copy:</source>
        <translation>Eingabe eines Namens für die Kopie:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="515"/>
        <location filename="../src/mainwindow.cpp" line="689"/>
        <source>In order for you to edit and save a conky, it must first be copied to ~/.conky where you have permission.
Enter a name for the copy.</source>
        <translation>Um ein Conky zu bearbeiten und speichern bitte zuerst nach ~/.conky mit entsprechenden Schreibrechten kopieren.
Eingabe eines Namens für die Kopie.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="532"/>
        <location filename="../src/mainwindow.cpp" line="708"/>
        <source>Directory Exists</source>
        <translation>Verzeichnis existiert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="533"/>
        <location filename="../src/mainwindow.cpp" line="709"/>
        <source>A conky with the name '%1' already exists in your personal folder.
Do you want to overwrite it?</source>
        <translation>Ein Conky mit dem Namen &apos;%1&apos; existiert bereits im persönlichen Verzeichnis.
Soll das überschrieben werden ?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="600"/>
        <source>Edit Conky</source>
        <translation>Conky bearbeiten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="601"/>
        <source>This conky file is read-only and requires administrator privileges to edit.
Do you want to edit it with elevated privileges?</source>
        <translation>Diese Conky Datei ist nur lesbar und es sind Administratorenrechte für das Bearbeiten erforderlich
Soll diese mit solchen Rechten bearbeitet werden ?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="630"/>
        <source>Are you sure you want to delete the conky file:
%1

This action cannot be undone.</source>
        <translation>Sicher, daß die Conky Datei
%1 gelöscht werden soll

Diese Aktion kann nicht rückgängig gemacht werden.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="662"/>
        <source>Delete Failed</source>
        <translation>Löschen fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="662"/>
        <source>Failed to delete conky file:
%1</source>
        <translation>Löschen der Conky Datei
%1 fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="750"/>
        <source>Customize Conky</source>
        <translation>Conky personalisieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="751"/>
        <source>This conky file is read-only and requires administrator privileges to customize.
Do you want to customize it with elevated privileges?</source>
        <translation>Diese Conky Datei ist nur lesbar und es sind Administratorenrechte für das Personalisieren erforderlich
Soll diese mit solchen Rechten personalisiert werden ?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="923"/>
        <source>Editor Error</source>
        <translation>Bearbeitungsfehler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="923"/>
        <source>Cannot start editor for file: %1</source>
        <translation>Editor für Datei: %1 konnte nicht gestartet werden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="933"/>
        <source>About MX Conky</source>
        <translation>Über MX-Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="935"/>
        <source>Version: </source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="936"/>
        <source>GUI program for configuring Conky in MX Linux</source>
        <translation>Grafische Anwendung, um Conky in MX-Linux zu konfigurieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="939"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="940"/>
        <source>License</source>
        <translation>Lizenz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="941"/>
        <location filename="../src/mainwindow.cpp" line="951"/>
        <source>Changelog</source>
        <translation>Änderungsprotokoll</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="942"/>
        <source>Cancel</source>
        <translation>Abbruch</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="136"/>
        <location filename="../src/mainwindow.cpp" line="962"/>
        <source>&amp;Close</source>
        <translation>&amp;Schließen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="979"/>
        <source>MX Conky Help</source>
        <translation>MX-Conky-Hilfe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1003"/>
        <location filename="../src/mainwindow.cpp" line="1052"/>
        <source>Autostart</source>
        <translation>Autostart</translation>
    </message>
</context>
<context>
    <name>PreviewDialog</name>
    <message>
        <location filename="../src/previewdialog.cpp" line="50"/>
        <source>Generate Preview</source>
        <translation>Erzeugung einer Vorschau</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="75"/>
        <source>Generate preview images for</source>
        <translation>Erzeugung von Vorschaubildern für</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="78"/>
        <source>Selected Widget</source>
        <translation>Ausgewähltes Widget</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="79"/>
        <source>All Widgets with Missing Previews</source>
        <translation>Alle Widgets mit fehlender Vorschau</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="80"/>
        <source>All Widgets (Overwrite Existing Images)</source>
        <translation>Alle Widgets (existierende Bilder werden überschrieben)</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="85"/>
        <source>No conky is currently selected</source>
        <translation>Kein Conky ausgewählt</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="93"/>
        <source>Options</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="96"/>
        <source>High quality images (PNG)</source>
        <translation>Hochqualitative Bilder (PNG)</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="97"/>
        <source>Generate preview images in PNG format instead of JPEG</source>
        <translation>Erzeugung von Vorschaubildern im PNG Format anstelle von JPEG</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="114"/>
        <source>OK</source>
        <translation>Weiter</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="118"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="145"/>
        <source>No Items</source>
        <translation>Keine Elemente</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="145"/>
        <source>No conky widgets need preview generation.</source>
        <translation>Kein Conky Widget benötigt eine Vorschauerstellung.</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="151"/>
        <source>Missing Dependency</source>
        <translation>Fehlende Abhängigkeit</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="152"/>
        <source>Preview generation requires the GraphicsMagick compatibility tools.
Please install the graphicsmagick-imagemagick-compat package to enable this feature.</source>
        <translation>Die Vorschauerzeugung benötigt die GraphicsMagick Kompatibilitäts-Tools.
Bitte das graphicsmagick-imagemagick-compat Paket installieren.</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="163"/>
        <source>Starting preview generation...</source>
        <translation>Start der Vorschauerzeugung...</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="167"/>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="206"/>
        <source>Generating preview for: %1</source>
        <translation>Vorschauerzeugung für: %1</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="426"/>
        <source>Preview generation complete! Generated %1 previews.</source>
        <translation>Vorschauerzeugung abgeschlossen! %1 Vorschauen erzeugt.</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="430"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="433"/>
        <source>Preview Generation Complete</source>
        <translation>Vorschauerzeugung abgeschlossen</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="434"/>
        <source>Successfully generated %1 preview images.</source>
        <translation>%1 Vorschaubilder erfolgreich erzeugt.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="68"/>
        <source>Select Conky Manager config file</source>
        <translation>Konfigurationsdatei des Conky-Managers wählen</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program as normal user</source>
        <translation>Diese Anwendung muss als normaler Benutzer ausgeführt werden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="163"/>
        <source>Could not load %1</source>
        <translation>%1 konnte nicht geladen werden.</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../src/settingsdialog.cpp" line="40"/>
        <location filename="../src/settingsdialog.cpp" line="62"/>
        <source>Select Conky Directory</source>
        <translation>Conky Verzeuchnis auswählen</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="83"/>
        <source>MX Conky Settings</source>
        <translation>MX Conky Einstellungen</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="91"/>
        <source>Search Paths</source>
        <translation>Suchpfade</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="92"/>
        <source>Autostart</source>
        <translation>Autostart</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="167"/>
        <source>Conky Search Paths</source>
        <translation>Conky Suchpfade</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="173"/>
        <source>Add Path</source>
        <translation>Pfad hinzufügen</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="176"/>
        <source>Remove Path</source>
        <translation>Pfad entfernen</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="179"/>
        <source>Edit Path</source>
        <translation>Pfad bearbeiten</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="206"/>
        <source>Autostart Settings</source>
        <translation>Autostart-Einstellungen</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="209"/>
        <source>Start conky at system startup</source>
        <translation>Conky beim Systemstart starten</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="212"/>
        <source>Startup delay (seconds):</source>
        <translation>Startverzögerung (Sekunden):</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="95"/>
        <source>OK</source>
        <translation>Weiter</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
</context>
</TS>