<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="nl_BE">
<context>
    <name>ConkyCustomizeDialog</name>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="45"/>
        <source>Customize Conky - %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="66"/>
        <source>Launch</source>
        <translation>Starten</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="70"/>
        <location filename="../src/conkycustomizedialog.cpp" line="331"/>
        <source>Start</source>
        <translation>Starten</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="72"/>
        <source>Undo</source>
        <translation>Ongedaan maken</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="95"/>
        <location filename="../src/conkycustomizedialog.cpp" line="175"/>
        <source>Colors</source>
        <translation>Kleuren</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="110"/>
        <source>Default</source>
        <translation>Standaard</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="110"/>
        <source>Color0</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="110"/>
        <source>Color1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="110"/>
        <source>Color2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="110"/>
        <source>Color3</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="110"/>
        <source>Color4</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="111"/>
        <source>Color5</source>
        <translation>Kleur5</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="111"/>
        <source>Color6</source>
        <translation>Kleur6</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="111"/>
        <source>Color7</source>
        <translation>Kleur7</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="111"/>
        <source>Color8</source>
        <translation>Kleur8</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="111"/>
        <source>Color9</source>
        <translation>Kleur9</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="182"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="326"/>
        <location filename="../src/conkycustomizedialog.cpp" line="331"/>
        <source>Stop</source>
        <translation>Stoppen</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="712"/>
        <source>Select Color</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="819"/>
        <source>Permission Denied</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="820"/>
        <source>Cannot write to file: %1
Insufficient permissions.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="830"/>
        <source>Write Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="830"/>
        <source>Cannot write to file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="934"/>
        <source>Backup Config File</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="934"/>
        <source>Do you want to preserve the original file?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="958"/>
        <source>Backed Up Config File</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="959"/>
        <source>The original configuration was backed up to %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="961"/>
        <source>Backup Failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="961"/>
        <source>Failed to create a backup file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1042"/>
        <location filename="../src/conkycustomizedialog.cpp" line="1045"/>
        <source>Restore Failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1042"/>
        <source>Failed to restore from backup file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1045"/>
        <source>Backup file does not exist.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1397"/>
        <source>Position</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1404"/>
        <source>Alignment</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1409"/>
        <source>Top Left</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1410"/>
        <source>Top Right</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1411"/>
        <source>Top Middle</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1412"/>
        <source>Bottom Left</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1413"/>
        <source>Bottom Right</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1414"/>
        <source>Bottom Middle</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1415"/>
        <source>Middle Left</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1416"/>
        <source>Middle Right</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1417"/>
        <source>Middle Middle</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1422"/>
        <source>Horizontal Gap</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1423"/>
        <source>[GAP_X] Horizontal distance from window border (in pixels)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1435"/>
        <source>Vertical Gap</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1436"/>
        <source>[GAP_Y] Vertical distance from window border (in pixels)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1448"/>
        <source>Desktop</source>
        <translation>Desktop</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1451"/>
        <source>Desktop 1</source>
        <translation>Desktop 1</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1452"/>
        <source>All Desktops</source>
        <translation>Alle Desktops</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1464"/>
        <source>Location</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1476"/>
        <source>Width should be larger than the size of window contents,
otherwise this setting will not have any effect</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1480"/>
        <source>Minimum Width</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1495"/>
        <source>Height should be larger than the size of window contents,
otherwise this setting will not have any effect</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1497"/>
        <source>Minimum Height</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1511"/>
        <source>Increases the window height by adding empty lines at the end of the Conky config file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1512"/>
        <source>Height Padding</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1527"/>
        <source>Size</source>
        <translation>Grootte</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1540"/>
        <source>Transparency Type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1545"/>
        <source>Opaque</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1546"/>
        <source>Transparent</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1547"/>
        <source>Pseudo-Transparent</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1548"/>
        <source>Semi-Transparent</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1553"/>
        <source>Opacity (%)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1554"/>
        <source>Window Opacity

0 = Fully Transparent, 100 = Fully Opaque</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1568"/>
        <source>Background Color</source>
        <translation>Achtergrond kleur</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1573"/>
        <source>Choose Color</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1593"/>
        <source>Setting Type to &quot;Transparent&quot; will make the whole window transparent (including any images). Use &quot;Pseudo-Transparent&quot; if you want the images to be opaque.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1603"/>
        <source>Setting Type to &quot;Pseudo-Transparent&quot; will make the window transparent but the window will have a shadow. The shadow can be disabled by configuring your window manager.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1614"/>
        <source>Transparency</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1625"/>
        <source>Date Format</source>
        <translation>Datumnotatie</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1628"/>
        <source>Day</source>
        <translation>Dag</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1630"/>
        <location filename="../src/conkycustomizedialog.cpp" line="1641"/>
        <source>Long</source>
        <translation>Lang</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1631"/>
        <location filename="../src/conkycustomizedialog.cpp" line="1642"/>
        <source>Short</source>
        <translation>Kort</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1632"/>
        <source>Abbreviated name, e.g. Tu</source>
        <translation>Afgekorte naam, bv. Di</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1639"/>
        <source>Month</source>
        <translation>Maand</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1643"/>
        <source>Abbreviated name, e.g. Oct</source>
        <translation>Afgekorte naam, bv. Okt</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1662"/>
        <source>Time Format</source>
        <translation>Tijd formaat:</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1669"/>
        <source>Format</source>
        <translation>Formaat</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1674"/>
        <source>12 Hour</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1675"/>
        <source>24 Hour</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="643"/>
        <location filename="../src/conkycustomizedialog.cpp" line="652"/>
        <location filename="../src/conkycustomizedialog.cpp" line="661"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1690"/>
        <source>Date &amp;&amp; Time</source>
        <translation>Datum &amp;&amp; Tijd</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1703"/>
        <source>Interface</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1711"/>
        <source>WiFi</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1714"/>
        <source>WiFi Network</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1717"/>
        <source>LAN</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1720"/>
        <source>Wired LAN Network</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1734"/>
        <source>Network</source>
        <translation>Netwerk</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="2055"/>
        <source>Select Background Color</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ConkyItemWidget</name>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="64"/>
        <source>Running</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="64"/>
        <source>Stopped</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="138"/>
        <source>Autostart</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="140"/>
        <source>Edit</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="143"/>
        <source>Customize</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="148"/>
        <source>Delete</source>
        <translation>Verwijder</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="177"/>
        <source>Stop</source>
        <translation>Stoppen</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="180"/>
        <source>Start</source>
        <translation>Starten</translation>
    </message>
</context>
<context>
    <name>ConkyListWidget</name>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="345"/>
        <source>Total: 0 conkies</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="595"/>
        <source>Total: %1 conkies</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="598"/>
        <source>Showing: %1 of %2 conkies</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ConkyPreviewWidget</name>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="548"/>
        <source>No Conky Selected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="550"/>
        <source>Select a conky from the list to see its preview</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="569"/>
        <source>Preview image could not be loaded</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="572"/>
        <source>No preview image available</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.cpp" line="57"/>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <source>MX Conky</source>
        <translation>MX Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="303"/>
        <source>About this application</source>
        <translation>Over deze applicatie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="301"/>
        <source>About...</source>
        <translation>Over...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="308"/>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="323"/>
        <source>Quit application</source>
        <translation>Verlaat de applicatie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="321"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <source>Loading Conky configurations...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="241"/>
        <source>Settings</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="243"/>
        <source>Configure conky search paths</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="245"/>
        <source>Refresh</source>
        <translation>Verversen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="247"/>
        <source>Refresh conky list</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="249"/>
        <source>Start Selected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="251"/>
        <source>Start selected conkies</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="253"/>
        <source>Stop All</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="255"/>
        <source>Stop all running conkies</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="824"/>
        <source>MX Conky License</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="875"/>
        <location filename="../src/mainwindow.cpp" line="926"/>
        <source>Running</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="877"/>
        <location filename="../src/mainwindow.cpp" line="927"/>
        <source>Stopped</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="263"/>
        <source>Search conky by name...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="265"/>
        <source>Search conkies by name (Ctrl+F)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="310"/>
        <source>Display help</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1073"/>
        <source>Copy Conky</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1121"/>
        <source>Conky Copied</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1120"/>
        <source>Conky has been copied to your personal folder for editing:
%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1097"/>
        <source>Copy Failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1097"/>
        <source>Failed to copy conky to your personal folder.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="534"/>
        <source>Delete Conky</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1119"/>
        <source>Conky has been copied to your personal folder for customization:
%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="237"/>
        <source>Previews</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="239"/>
        <source>Generate preview images for conkies</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="259"/>
        <location filename="../src/mainwindow.cpp" line="873"/>
        <location filename="../src/mainwindow.cpp" line="925"/>
        <location filename="../src/mainwindow.cpp" line="1107"/>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="260"/>
        <source>Filter conkies by running status or location</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1069"/>
        <source>Enter a name for the copy:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1070"/>
        <source>In order for you to edit and save a conky, it must first be copied to ~/.conky where you have permission.
Enter a name for the copy.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1085"/>
        <source>Directory Exists</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1086"/>
        <source>A conky with the name '%1' already exists in your personal folder.
Do you want to overwrite it?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="505"/>
        <source>Edit Conky</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="506"/>
        <source>This conky file is read-only and requires administrator privileges to edit.
Do you want to edit it with elevated privileges?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="535"/>
        <source>Are you sure you want to delete the conky file:
%1

This action cannot be undone.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="572"/>
        <source>Delete Failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="572"/>
        <source>Failed to delete conky file:
%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="601"/>
        <source>Customize Conky</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="602"/>
        <source>This conky file is read-only and requires administrator privileges to customize.
Do you want to customize it with elevated privileges?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="799"/>
        <source>Editor Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="799"/>
        <source>Cannot start editor for file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="809"/>
        <source>About MX Conky</source>
        <translation>Over MX Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="811"/>
        <source>Version: </source>
        <translation>Versie:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="812"/>
        <source>GUI program for configuring Conky in MX Linux</source>
        <translation>GUI programma voor configuratie van Conky in MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="815"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="816"/>
        <source>License</source>
        <translation>Licentie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="817"/>
        <location filename="../src/mainwindow.cpp" line="827"/>
        <source>Changelog</source>
        <translation>Changelog</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="818"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="129"/>
        <location filename="../src/mainwindow.cpp" line="838"/>
        <source>&amp;Close</source>
        <translation>&amp;Sluiten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="855"/>
        <source>MX Conky Help</source>
        <translation>MX Conky Hulp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="879"/>
        <location filename="../src/mainwindow.cpp" line="928"/>
        <source>Autostart</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PreviewDialog</name>
    <message>
        <location filename="../src/previewdialog.cpp" line="51"/>
        <source>Generate Preview</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="82"/>
        <source>Generate preview images for</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="85"/>
        <source>Selected Widget</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="86"/>
        <source>All Widgets with Missing Previews</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="87"/>
        <source>All Widgets (Overwrite Existing Images)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="92"/>
        <source>No conky is currently selected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="100"/>
        <source>Options</source>
        <translation>Opties</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="103"/>
        <source>High quality images (PNG)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="104"/>
        <source>Generate preview images in PNG format instead of JPEG</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="121"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="125"/>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="152"/>
        <source>No Items</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="152"/>
        <source>No conky widgets need preview generation.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="158"/>
        <source>Missing Dependency</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="159"/>
        <source>Preview generation requires the GraphicsMagick compatibility tools.
Please install the graphicsmagick-imagemagick-compat package to enable this feature.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="174"/>
        <source>Starting preview generation...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="178"/>
        <source>Stop</source>
        <translation>Stoppen</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="217"/>
        <source>Generating preview for: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="253"/>
        <source>Unsupported Display Server</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="254"/>
        <source>Preview generation requires X11 and is not supported on Wayland.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="451"/>
        <source>Preview generation complete! Generated %1 previews.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="455"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="458"/>
        <source>Preview Generation Complete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="459"/>
        <source>Successfully generated %1 preview images.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="68"/>
        <source>Select Conky Manager config file</source>
        <translation>Selecteer Conky Beheer configuratiebestand</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Error</source>
        <translation>Foutmelding</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program as normal user</source>
        <translation>U moet dit programma als normale gebruiker uitvoeren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="156"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../src/settingsdialog.cpp" line="40"/>
        <location filename="../src/settingsdialog.cpp" line="62"/>
        <source>Select Conky Directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="83"/>
        <source>MX Conky Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="91"/>
        <source>Search Paths</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="92"/>
        <source>Autostart</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="167"/>
        <source>Conky Search Paths</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="173"/>
        <source>Add Path</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="176"/>
        <source>Remove Path</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="179"/>
        <source>Edit Path</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="206"/>
        <source>Autostart Settings</source>
        <translation>Autostart Instellingen</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="209"/>
        <source>Start conky at system startup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="212"/>
        <source>Startup delay (seconds):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="95"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
</context>
</TS>