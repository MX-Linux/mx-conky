<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pt_BR">
<context>
    <name>ConkyCustomizeDialog</name>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="45"/>
        <source>Customize Conky - %1</source>
        <translation>Personalizar o Monitor do Sistema Conky %1</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="66"/>
        <source>Launch</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="70"/>
        <location filename="../src/conkycustomizedialog.cpp" line="331"/>
        <source>Start</source>
        <translation>Iniciar</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="72"/>
        <source>Undo</source>
        <translation>Desfazer</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="95"/>
        <location filename="../src/conkycustomizedialog.cpp" line="175"/>
        <source>Colors</source>
        <translation>Cores</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="110"/>
        <source>Default</source>
        <translation>Padrão</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="110"/>
        <source>Color0</source>
        <translation>Cor 0</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="110"/>
        <source>Color1</source>
        <translation>Cor 1</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="110"/>
        <source>Color2</source>
        <translation>Cor 2</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="110"/>
        <source>Color3</source>
        <translation>Cor 3</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="110"/>
        <source>Color4</source>
        <translation>Cor 4</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="111"/>
        <source>Color5</source>
        <translation>Cor 5</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="111"/>
        <source>Color6</source>
        <translation>Cor 6</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="111"/>
        <source>Color7</source>
        <translation>Cor 7</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="111"/>
        <source>Color8</source>
        <translation>Cor 8</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="111"/>
        <source>Color9</source>
        <translation>Cor 9</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="182"/>
        <source>Close</source>
        <translation>Fechar </translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="326"/>
        <location filename="../src/conkycustomizedialog.cpp" line="331"/>
        <source>Stop</source>
        <translation>Parar</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="712"/>
        <source>Select Color</source>
        <translation>Selecionar a Cor</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="819"/>
        <source>Permission Denied</source>
        <translation>A Permissão Foi Negada</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="820"/>
        <source>Cannot write to file: %1
Insufficient permissions.</source>
        <translation>Não foi possível gravar no arquivo %1.
As permissões não são suficientes.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="830"/>
        <source>Write Error</source>
        <translation>Ocorreu um Erro de Gravação</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="830"/>
        <source>Cannot write to file: %1</source>
        <translation>Não foi possível gravar no arquivo %1</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="934"/>
        <source>Backup Config File</source>
        <translation>Fazer uma Cópia de Segurança
do Arquivo de Configurações</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="934"/>
        <source>Do you want to preserve the original file?</source>
        <translation>Você quer preservar o arquivo original?</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="958"/>
        <source>Backed Up Config File</source>
        <translation>Foi Feito uma Cópia de Segurança
do Arquivo de Configurações</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="959"/>
        <source>The original configuration was backed up to %1</source>
        <translation>Foi feito a cópia de segurança do arquivo
de configurações original %1</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="961"/>
        <source>Backup Failed</source>
        <translation>Ocorreu uma Falha na Cópia Segurança</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="961"/>
        <source>Failed to create a backup file.</source>
        <translation>Ocorreu uma falha ao criar o arquivo
da cópia de segurança.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1042"/>
        <location filename="../src/conkycustomizedialog.cpp" line="1045"/>
        <source>Restore Failed</source>
        <translation>Ocorreu uma Falha na Restauração</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1042"/>
        <source>Failed to restore from backup file.</source>
        <translation>Ocorreu uma falha ao tentar restaurar a
partir do arquivo da cópia de segurança.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1045"/>
        <source>Backup file does not exist.</source>
        <translation>O arquivo da cópia de
segurança não existe.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1397"/>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1404"/>
        <source>Alignment</source>
        <translation>Alinhamento</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1409"/>
        <source>Top Left</source>
        <translation>No canto superior esquerdo</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1410"/>
        <source>Top Right</source>
        <translation>No canto superior esquerdo direito</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1411"/>
        <source>Top Middle</source>
        <translation>No canto superior e no centro</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1412"/>
        <source>Bottom Left</source>
        <translation>No canto inferior esquerdo</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1413"/>
        <source>Bottom Right</source>
        <translation>No canto inferior direito</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1414"/>
        <source>Bottom Middle</source>
        <translation>No canto inferior e no centro</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1415"/>
        <source>Middle Left</source>
        <translation>No canto esquerdo e no centro</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1416"/>
        <source>Middle Right</source>
        <translation>No canto direito e no centro</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1417"/>
        <source>Middle Middle</source>
        <translation>No centro da tela</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1422"/>
        <source>Horizontal Gap</source>
        <translation>Distância Horizontal</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1423"/>
        <source>[GAP_X] Horizontal distance from window border (in pixels)</source>
        <translation>O [GAP_X] é distância horizontal da borda da janela em pixels</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1435"/>
        <source>Vertical Gap</source>
        <translation>Distância Vertical</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1436"/>
        <source>[GAP_Y] Vertical distance from window border (in pixels)</source>
        <translation>O [GAP_Y] é distância vertical da borda da janela em pixels</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1448"/>
        <source>Desktop</source>
        <translation>Área de Trabalho</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1451"/>
        <source>Desktop 1</source>
        <translation>Área de Trabalho 1</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1452"/>
        <source>All Desktops</source>
        <translation>Todas as Áreas de Trabalho</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1464"/>
        <source>Location</source>
        <translation>Localização</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1476"/>
        <source>Width should be larger than the size of window contents,
otherwise this setting will not have any effect</source>
        <translation>A largura deve ser maior do que o tamanho do conteúdo
da janela, caso contrário, esta configuração não terá
nenhum efeito</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1480"/>
        <source>Minimum Width</source>
        <translation>Largura Mínima</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1495"/>
        <source>Height should be larger than the size of window contents,
otherwise this setting will not have any effect</source>
        <translation>A altura deve ser maior do que o tamanho do conteúdo
da janela, caso contrário, esta configuração não terá
nenhum efeito</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1497"/>
        <source>Minimum Height</source>
        <translation>Altura Mínima</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1511"/>
        <source>Increases the window height by adding empty lines at the end of the Conky config file</source>
        <translation>Para aumentar a altura da janela, adicione linhas vazias ou em branco no final do arquivo de configurações do Conky</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1512"/>
        <source>Height Padding</source>
        <translation>Altura do Preenchimento</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1527"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1540"/>
        <source>Transparency Type</source>
        <translation>Tipo da Transparência</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1545"/>
        <source>Opaque</source>
        <translation>Opaco</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1546"/>
        <source>Transparent</source>
        <translation>Transparente</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1547"/>
        <source>Pseudo-Transparent</source>
        <translation>Pseudo-Transparência</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1548"/>
        <source>Semi-Transparent</source>
        <translation>Semitransparente</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1553"/>
        <source>Opacity (%)</source>
        <translation>Opacidade (%)</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1554"/>
        <source>Window Opacity

0 = Fully Transparent, 100 = Fully Opaque</source>
        <translation>Opacidade da Janela

0 = Totalmente Transparente
100 = Totalmente Opaco</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1568"/>
        <source>Background Color</source>
        <translation>Cor do Plano de Fundo</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1573"/>
        <source>Choose Color</source>
        <translation>Escolher a Cor</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1593"/>
        <source>Setting Type to &quot;Transparent&quot; will make the whole window transparent (including any images). Use &quot;Pseudo-Transparent&quot; if you want the images to be opaque.</source>
        <translation>Quando o tipo da configuração foi definida como ‘Transparente’ tornará toda a janela transparente (incluindo quaisquer imagens). Utilize a opção ‘Pseudo-Transparente’ se você quiser que as imagens sejam opacas.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1603"/>
        <source>Setting Type to &quot;Pseudo-Transparent&quot; will make the window transparent but the window will have a shadow. The shadow can be disabled by configuring your window manager.</source>
        <translation>Quando o tipo da configuração foi definida como ‘Pseudo-Transparente’ tornará a janela transparente, mas ela terá uma sombra. A sombra pode ser desativada configurando o seu gerenciador de janelas.</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1614"/>
        <source>Transparency</source>
        <translation>Transparência</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1625"/>
        <source>Date Format</source>
        <translation>Formato da Data</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1628"/>
        <source>Day</source>
        <translation>Dia</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1630"/>
        <location filename="../src/conkycustomizedialog.cpp" line="1641"/>
        <source>Long</source>
        <translation>Longo</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1631"/>
        <location filename="../src/conkycustomizedialog.cpp" line="1642"/>
        <source>Short</source>
        <translation>Curto</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1632"/>
        <source>Abbreviated name, e.g. Tu</source>
        <translation>O nome abreviado, por exemplo,
‘Ter’ para ‘Terça-Feira’</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1639"/>
        <source>Month</source>
        <translation>Mês</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1643"/>
        <source>Abbreviated name, e.g. Oct</source>
        <translation>O nome abreviado, por exemplo,
‘Out’ para ‘Outubro’</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1662"/>
        <source>Time Format</source>
        <translation>Formato da Hora</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1669"/>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1674"/>
        <source>12 Hour</source>
        <translation>12 horas</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1675"/>
        <source>24 Hour</source>
        <translation>24 horas</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="643"/>
        <location filename="../src/conkycustomizedialog.cpp" line="652"/>
        <location filename="../src/conkycustomizedialog.cpp" line="661"/>
        <source>auto</source>
        <translation>automático</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1690"/>
        <source>Date &amp;&amp; Time</source>
        <translation>Data e Hora</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1703"/>
        <source>Interface</source>
        <translation>Interface</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1711"/>
        <source>WiFi</source>
        <translation>Sem Fio</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1714"/>
        <source>WiFi Network</source>
        <translation>Rede Sem Fio</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1717"/>
        <source>LAN</source>
        <translation>Com Fio</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1720"/>
        <source>Wired LAN Network</source>
        <translation>Rede Local Com Fio</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="1734"/>
        <source>Network</source>
        <translation>Internet</translation>
    </message>
    <message>
        <location filename="../src/conkycustomizedialog.cpp" line="2055"/>
        <source>Select Background Color</source>
        <translation>Selecionar a Cor de Fundo</translation>
    </message>
</context>
<context>
    <name>ConkyItemWidget</name>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="64"/>
        <source>Running</source>
        <translation>Executando</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="64"/>
        <source>Stopped</source>
        <translation>Parado</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="138"/>
        <source>Autostart</source>
        <translation>Iniciar Automaticamente</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="140"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="143"/>
        <source>Customize</source>
        <translation>Personalizar</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="148"/>
        <source>Delete</source>
        <translation>Excluir</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="177"/>
        <source>Stop</source>
        <translation>Parar</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="180"/>
        <source>Start</source>
        <translation>Iniciar</translation>
    </message>
</context>
<context>
    <name>ConkyListWidget</name>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="345"/>
        <source>Total: 0 conkies</source>
        <translation>Total de 0 Conkies</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="595"/>
        <source>Total: %1 conkies</source>
        <translation>Total de %1 Conkies</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="598"/>
        <source>Showing: %1 of %2 conkies</source>
        <translation>Exibindo %1 de %2 Conkies</translation>
    </message>
</context>
<context>
    <name>ConkyPreviewWidget</name>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="548"/>
        <source>No Conky Selected</source>
        <translation>O Conky Não Foi Selecionado</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="550"/>
        <source>Select a conky from the list to see its preview</source>
        <translation>Selecione um Conky na lista para pré-visualizar o seu modelo</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="569"/>
        <source>Preview image could not be loaded</source>
        <translation>A imagem da pré-visualização não pôde ser carregada</translation>
    </message>
    <message>
        <location filename="../src/conkylistwidget.cpp" line="572"/>
        <source>No preview image available</source>
        <translation>Não tem uma imagem disponível para a pré-visualização</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.cpp" line="57"/>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <source>MX Conky</source>
        <translation>Conky do MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="303"/>
        <source>About this application</source>
        <translation>Sobre este programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="301"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="308"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="323"/>
        <source>Quit application</source>
        <translation>Sair do programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="321"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="211"/>
        <source>Loading Conky configurations...</source>
        <translation>Carregando as configurações do Conky...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="241"/>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="243"/>
        <source>Configure conky search paths</source>
        <translation>Configurar os caminhos para pesquisar o Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="245"/>
        <source>Refresh</source>
        <translation>Recarregar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="247"/>
        <source>Refresh conky list</source>
        <translation>Atualizar lista do Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="249"/>
        <source>Start Selected</source>
        <translation>Executar o Selecionado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="251"/>
        <source>Start selected conkies</source>
        <translation>Executar os Conkies selecionados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="253"/>
        <source>Stop All</source>
        <translation>Parar Todos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="255"/>
        <source>Stop all running conkies</source>
        <translation>Parar todos os Conkies que estão em execução</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="824"/>
        <source>MX Conky License</source>
        <translation>Licença do Conky do MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="875"/>
        <location filename="../src/mainwindow.cpp" line="926"/>
        <source>Running</source>
        <translation>Executando</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="877"/>
        <location filename="../src/mainwindow.cpp" line="927"/>
        <source>Stopped</source>
        <translation>Parado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="263"/>
        <source>Search conky by name...</source>
        <translation>Pesquisar pelo nome do Conky...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="265"/>
        <source>Search conkies by name (Ctrl+F)</source>
        <translation>Pesquisar pelo nome do Conky (Ctrl+F)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="310"/>
        <source>Display help</source>
        <translation>Exibir ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1073"/>
        <source>Copy Conky</source>
        <translation>Copiar o Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1121"/>
        <source>Conky Copied</source>
        <translation>O Conky Foi Copiado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1120"/>
        <source>Conky has been copied to your personal folder for editing:
%1</source>
        <translation>O Conky foi copiado para sua pasta pessoal para ser editado:
%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1097"/>
        <source>Copy Failed</source>
        <translation>Ocorreu Falha ao Copiar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1097"/>
        <source>Failed to copy conky to your personal folder.</source>
        <translation>Ocorreu uma falha ao copiar o Conky para sua pasta pessoal.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="534"/>
        <source>Delete Conky</source>
        <translation>Excluir o Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1119"/>
        <source>Conky has been copied to your personal folder for customization:
%1</source>
        <translation>O Conky foi copiado para sua pasta pessoal para ser personalizado:
%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="237"/>
        <source>Previews</source>
        <translation>Pré-Visualização</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="239"/>
        <source>Generate preview images for conkies</source>
        <translation>Gerar as imagens para a pré-visualização dos Conkies</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="259"/>
        <location filename="../src/mainwindow.cpp" line="873"/>
        <location filename="../src/mainwindow.cpp" line="925"/>
        <location filename="../src/mainwindow.cpp" line="1107"/>
        <source>All</source>
        <translation>Todos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="260"/>
        <source>Filter conkies by running status or location</source>
        <translation>Filtrar os Conkies por estado de execução ou por sua localização</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1069"/>
        <source>Enter a name for the copy:</source>
        <translation>Insira um nome para fazer a cópia:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1070"/>
        <source>In order for you to edit and save a conky, it must first be copied to ~/.conky where you have permission.
Enter a name for the copy.</source>
        <translation>Para editar e salvar um Conky, primeiro copie o arquivo para a pasta ‘~/.conky’ (/home/nome do usuário/.conky), onde você tem as permissões para modificar o arquivo.
Insira um nome para fazer a cópia.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1085"/>
        <source>Directory Exists</source>
        <translation>Diretório Existente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1086"/>
        <source>A conky with the name '%1' already exists in your personal folder.
Do you want to overwrite it?</source>
        <translation>Já existe um Conky com o nome ‘%1’ na sua pasta pessoal.
Você quer substituí-lo?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="505"/>
        <source>Edit Conky</source>
        <translation>Editar o Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="506"/>
        <source>This conky file is read-only and requires administrator privileges to edit.
Do you want to edit it with elevated privileges?</source>
        <translation>Este arquivo do Conky é somente para leitura e requer as permissões de administrador (root) para ser editado.
Você quer editá-lo com as permissões de administrador?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="535"/>
        <source>Are you sure you want to delete the conky file:
%1

This action cannot be undone.</source>
        <translation>Você tem certeza de que quer excluir o arquivo do Conky:
%1

Esta ação não poderá ser desfeita.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="572"/>
        <source>Delete Failed</source>
        <translation>Ocorreu uma Falha ao Tentar Excluir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="572"/>
        <source>Failed to delete conky file:
%1</source>
        <translation>Ocorreu uma falha ao tentar excluir o arquivo do Conky:
%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="601"/>
        <source>Customize Conky</source>
        <translation>Personalizar o Conky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="602"/>
        <source>This conky file is read-only and requires administrator privileges to customize.
Do you want to customize it with elevated privileges?</source>
        <translation>Este arquivo do Conky é somente para leitura e requer as permissões de administrador (root) para ser personalizado.
Você quer personalizá-lo com as permissões de administrador?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="799"/>
        <source>Editor Error</source>
        <translation>Ocorreu um Erro no Editor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="799"/>
        <source>Cannot start editor for file: %1</source>
        <translation>Não foi possível iniciar o editor do arquivo %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="809"/>
        <source>About MX Conky</source>
        <translation>Sobre o Conky do MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="811"/>
        <source>Version: </source>
        <translation>Versão: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="812"/>
        <source>GUI program for configuring Conky in MX Linux</source>
        <translation>Interface Gráfica do Usuário para configurar o Conky no MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="815"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Direitos de Autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="816"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="817"/>
        <location filename="../src/mainwindow.cpp" line="827"/>
        <source>Changelog</source>
        <translation>Relatório de alterações</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="818"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="129"/>
        <location filename="../src/mainwindow.cpp" line="838"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="855"/>
        <source>MX Conky Help</source>
        <translation>Ajuda do Conky do MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="879"/>
        <location filename="../src/mainwindow.cpp" line="928"/>
        <source>Autostart</source>
        <translation>Iniciar Automaticamente</translation>
    </message>
</context>
<context>
    <name>PreviewDialog</name>
    <message>
        <location filename="../src/previewdialog.cpp" line="51"/>
        <source>Generate Preview</source>
        <translation>Gerar a Pré-Visualização</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="82"/>
        <source>Generate preview images for</source>
        <translation>Gerar a pré-visualização da imagem para</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="85"/>
        <source>Selected Widget</source>
        <translation>A Ferramenta Foi Selecionada</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="86"/>
        <source>All Widgets with Missing Previews</source>
        <translation>A Ferramenta para a Pré-Visualização Não Está Disponível</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="87"/>
        <source>All Widgets (Overwrite Existing Images)</source>
        <translation>Todas as Ferramentas (Substituir as Imagens Existentes)</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="92"/>
        <source>No conky is currently selected</source>
        <translation>Nenhum Conky está selecionado neste exato momento</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="100"/>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="103"/>
        <source>High quality images (PNG)</source>
        <translation>Imagens de alta qualidade no formato PNG</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="104"/>
        <source>Generate preview images in PNG format instead of JPEG</source>
        <translation>Gerar a imagem para a pré-visualização no formato PNG
ao invés do formato JPEG</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="121"/>
        <source>OK</source>
        <translation>Continuar</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="125"/>
        <source>Cancel</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="152"/>
        <source>No Items</source>
        <translation>Nenhum Item</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="152"/>
        <source>No conky widgets need preview generation.</source>
        <translation>Não tem uma ferramenta para a geração da
pré-visualização do Conky.</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="158"/>
        <source>Missing Dependency</source>
        <translation>Um ou mais arquivos estão faltando.</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="159"/>
        <source>Preview generation requires the GraphicsMagick compatibility tools.
Please install the graphicsmagick-imagemagick-compat package to enable this feature.</source>
        <translation>A geração da prévia requer as ferramentas de compatibilidade ‘GraphicsMagick’. Para habilitar este recurso, favor instalar o pacote ‘graphicsmagick-imagemagick-compat’.</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="174"/>
        <source>Starting preview generation...</source>
        <translation>Iniciando a geração da pré-visualização...</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="178"/>
        <source>Stop</source>
        <translation>Parar</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="217"/>
        <source>Generating preview for: %1</source>
        <translation>Gerando a pré-visualização da imagem para o %1</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="253"/>
        <source>Unsupported Display Server</source>
        <translation>Este Servidor de Exibição não é suportado</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="254"/>
        <source>Preview generation requires X11 and is not supported on Wayland.</source>
        <translation>A geração da prévia não suporta o protocolo Wayland, sendo necessário o X11.</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="451"/>
        <source>Preview generation complete! Generated %1 previews.</source>
        <translation>A pré-visualização foi concluída com sucesso!
Foi gerado a imagem %1 para a pré-visualização.</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="455"/>
        <source>Close</source>
        <translation>Fechar </translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="458"/>
        <source>Preview Generation Complete</source>
        <translation>A Geração da Pré-Visualização Foi Concluída com Sucesso</translation>
    </message>
    <message>
        <location filename="../src/previewdialog.cpp" line="459"/>
        <source>Successfully generated %1 preview images.</source>
        <translation>A imagem %1 para a pré-visualização foi geradas com sucesso.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="68"/>
        <source>Select Conky Manager config file</source>
        <translation>Selecionar o arquivo de configuração do Gerenciador do Conky</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Error</source>
        <translation>Ocorreu um erro</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program as normal user</source>
        <translation>Você tem de que executar este programa com o usuário normal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="156"/>
        <source>Could not load %1</source>
        <translation>Não foi possível carregar o %1</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../src/settingsdialog.cpp" line="40"/>
        <location filename="../src/settingsdialog.cpp" line="62"/>
        <source>Select Conky Directory</source>
        <translation>Selecionar o Diretório do Conky</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="83"/>
        <source>MX Conky Settings</source>
        <translation>Configurações do Conky do MX</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="91"/>
        <source>Search Paths</source>
        <translation>Caminhos para a pesquisa</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="92"/>
        <source>Autostart</source>
        <translation>Iniciar Automaticamente</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="167"/>
        <source>Conky Search Paths</source>
        <translation>Caminhos para a Pesquisa do Conky</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="173"/>
        <source>Add Path</source>
        <translation>Adicionar o Caminho</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="176"/>
        <source>Remove Path</source>
        <translation>Remover o Caminho</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="179"/>
        <source>Edit Path</source>
        <translation>Editar o Caminho</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="206"/>
        <source>Autostart Settings</source>
        <translation>Configurações de Inicialização Automática</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="209"/>
        <source>Start conky at system startup</source>
        <translation>Adicionar o Conky na inicialização do sistema operacional</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="212"/>
        <source>Startup delay (seconds):</source>
        <translation>Inicializar com um tempo de atraso em segundos de:</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="95"/>
        <source>OK</source>
        <translation>Continuar</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Fechar</translation>
    </message>
</context>
</TS>